﻿using Easter.Core.Contracts;
using Easter.Models.Bunnies;
using Easter.Models.Bunnies.Contracts;
using Easter.Models.Dyes;
using Easter.Models.Eggs;
using Easter.Models.Eggs.Contracts;
using Easter.Models.Workshops;
using Easter.Models.Workshops.Contracts;
using Easter.Repositories;
using Easter.Repositories.Contracts;
using Easter.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Easter.Core
{
    public class Controller : IController
    {
        private IRepository<IBunny> bunnyRepos;
        private IRepository<IEgg> eggRepos;
        private IWorkshop workshop;
        private int countColloredEggs = 0;

        public Controller()
        {
            bunnyRepos = new BunnyRepository();
            eggRepos = new EggRepository();
            workshop = new Workshop();
        }
        
        public string AddBunny(string bunnyType, string bunnyName)
        {
            if (bunnyType == nameof(HappyBunny))
            {
                bunnyRepos.Add(new HappyBunny(bunnyName));
            }
            else if (bunnyType == nameof(SleepyBunny))
            {
                bunnyRepos.Add(new SleepyBunny(bunnyName));
            }
            else
            {
                throw new InvalidOperationException(ExceptionMessages.InvalidBunnyType);
            }
            return string.Format(OutputMessages.BunnyAdded, bunnyType, bunnyName);
        }

        public string AddDyeToBunny(string bunnyName, int power)
        {
            if (!bunnyRepos.Models.Any(x => x.Name == bunnyName))
            {
                throw new InvalidOperationException(ExceptionMessages.InexistentBunny);
            }
            bunnyRepos.FindByName(bunnyName).AddDye(new Dye(power));
            return string.Format(OutputMessages.DyeAdded, power, bunnyName);
        }

        public string AddEgg(string eggName, int energyRequired)
        {
            eggRepos.Add(new Egg(eggName, energyRequired));
            return string.Format(OutputMessages.EggAdded, eggName);
        }
       

        public string ColorEgg(string eggName)
        {
            
            if(bunnyRepos.Models.Where(x => x.Energy >= 50).Count() == 0)
            {
                throw new InvalidOperationException(ExceptionMessages.BunniesNotReady);
            }
            
                foreach (var bunny in bunnyRepos.Models.Where(x => x.Energy >= 50).OrderByDescending(x => x.Energy))
                {
                    workshop.Color(eggRepos.FindByName(eggName), bunny);
                    if (bunny.Energy == 0)
                    {
                        bunnyRepos.Remove(bunny);

                    }
                    if (eggRepos.FindByName(eggName).IsDone())
                    {
                        countColloredEggs++;
                        break;
                    }
                }
            
            if (eggRepos.FindByName(eggName).IsDone())
            {
                return string.Format(OutputMessages.EggIsDone, eggName);
            }
            return string.Format(OutputMessages.EggIsNotDone, eggName);
            
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{countColloredEggs} eggs are done!");
            sb.AppendLine("Bunnys info:");
            foreach (var bunnies in bunnyRepos.Models)
            {
                sb.Append(bunnies.ToString());
            }
            return sb.ToString().TrimEnd();
        }
    }
}
