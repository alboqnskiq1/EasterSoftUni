﻿using Easter.Models.Eggs.Contracts;
using Easter.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Easter.Repositories
{
    public class EggRepository : IRepository<IEgg>
    {
        private List<IEgg> eggColl;

        public EggRepository()
        {
            eggColl = new List<IEgg>();
        }

        public IReadOnlyCollection<IEgg> Models => eggColl;

        public void Add(IEgg model) => eggColl.Add(model);

        public IEgg FindByName(string name) => !eggColl.Any(x => x.Name == name) ? null : eggColl.FirstOrDefault(x => x.Name == name);


        public bool Remove(IEgg model) => !eggColl.Contains(model) ? false : eggColl.Remove(model);
        
    }
}
